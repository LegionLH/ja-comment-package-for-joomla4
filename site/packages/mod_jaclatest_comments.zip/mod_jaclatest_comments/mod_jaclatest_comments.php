<?php
/**
 * $JA#COPYRIGHT$
 */

defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__) . DS . 'helper.php');
modJACLatestItemsHelper::loadStyle($module);
$list = modJACLatestItemsHelper::getList($params);
modJACLatestItemsHelper::parseItems($params, $list);
$list = array_values(array_filter($list));
require (JModuleHelper::getLayoutPath('mod_jaclatest_comments'));
?>