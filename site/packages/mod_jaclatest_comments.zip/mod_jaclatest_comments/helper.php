<?php
/**
 * $JA#COPYRIGHT$
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
require_once (JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'helpers' . DS . 'jahelper.php');
/**
 *
 * JA LATEST COMMENTS HELPER CLASS
 * @author JoomlArt
 *
 */
class modJACLatestItemsHelper
{
    
	/**
	 *
	 * Get K2 category children
	 * @param int $catid
	 * @param boolean $clear if true return array which is removed value construction
	 * @return array
	 */
	static function getK2CategoryChildren($catid, $clear = false) {

		static $array = array();
		if ($clear)
		$array = array();
		$user = JFactory::getUser();
		$aid = $user->get('aid') ? $user->get('aid') : 1;
		$catid = (int) $catid;
		$db = JFactory::getDBO();
		$query = "SELECT * FROM #__k2_categories WHERE parent={$catid} AND published=1 AND trash=0 AND access<={$aid} ORDER BY ordering ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();

		foreach ($rows as $row) {
			array_push($array, $row->id);
			if (modJACLatestItemsHelper::hasK2Children($row->id)) {
				modJACLatestItemsHelper::getK2CategoryChildren($row->id);
			}
		}
		return $array;
	}


	/**
	 *
	 * Check category has children
	 * @param int $id
	 * @return boolean
	 */
	static function hasK2Children($id) {

		$user = JFactory::getUser();
		$aid = $user->get('aid') ? $user->get('aid') : 1;
		$id = (int) $id;
		$db = JFactory::getDBO();
		$query = "SELECT * FROM #__k2_categories WHERE parent={$id} AND published=1 AND trash=0 AND access<={$aid} ";
		$db->setQuery($query);
		$rows = $db->loadObjectList();

		if (count($rows)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
     * Get list comments
     *
     * @param object $params
	 * 
     * @return array
     */
    static function getList(&$params)
    {
        $source = $params->get("type", "");
        $items = array();

        $order = '';
        $type = $params->get("sort_type", 1);
        if ($type == "1") {
            $order = " id";
        } else {
            $order = " voted";
        }

        $count = $params->get("count", 1);

        $items = modJACLatestItemsHelper::getLatestFromComponent($params, $source, $order, $count);

        return $items;
    }

    /**
     * Build query get list comment for article joomla
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    static function getLatestFromContent($params, $source)
    {
        $queryContent = '';
        if ($source[0] == '' || in_array('com_content', $source)) {
            // generate query for com_content
            $content_category = $params->get("type-com_content-content_category", array());
			reset($content_category);
            $where = "cm2.type = 1";
            $where .= " AND cm2.option = 'com_content'";
            $where .= " AND c.state != -2 AND c.state != 0";
			if (current($content_category)!="") {
				if (!is_array($content_category)) {
					$content_category = array($content_category);
				}

				if (count($content_category)) {
					$where .= " AND c.catid IN (" . implode(',', $content_category) . ")";
				}
			}

			$queryContent = "SELECT cm2.*, c.title AS content_title FROM #__jacomment_items cm2"
						. "\n LEFT JOIN #__content c ON cm2.contentid = c.id"
						. "\n WHERE {$where}";
		}
        return $queryContent;
    }

    /**
     * Build query get list comment for article K2
	 * 
     * @param object $params
     * @param string $source
	 * 
     * @return string
	 */	
	static function getLatestFromK2($params, $source)
	{
		$db = JFactory::getDBO();
		
		$queryK2 = '';
		if ($source[0] == '' || in_array('com_k2', $source)) {
			if (self::checkComponent('com_k2')) {
				// generate query for com_k2
				$k2_category = $params->get("type-com_content-k2_category", array());
				
				$where = "cm3.type = 1";
				$where .= " AND cm3.option = 'com_k2'";
				$where .= " AND i.published = 1";
				
				if (!is_array($k2_category)) {
					$k2_category = array($k2_category);
				}
				
				JArrayHelper::toInteger($k2_category);
				if ($k2_category) {
					if ($k2_category && count($k2_category) > 0) {
						foreach ($k2_category as $k => $catid) {
							if (!$catid)
								unset($k2_category[$k]);
						}
					}
				}			
				
				reset($k2_category);
				if (current($k2_category)!="") {				
					if ($k2_category) {
						$catids_new = $k2_category;
						foreach ($k2_category as $k => $catid) {
							$subcatids = modJACLatestItemsHelper::getK2CategoryChildren($catid, true);
							if ($subcatids) {
								$catids_new = array_merge($catids_new, array_diff($subcatids, $catids_new));
							}
						}
						$k2_category = implode(',', $catids_new);
						$where .= "\n AND i.catid IN ($k2_category)";
					}				
				}
				
				$queryK2 = "SELECT cm3.*, i.title AS content_title FROM #__jacomment_items cm3"
							. "\n LEFT JOIN #__k2_items i ON cm3.contentid = i.id"
							. "\n WHERE {$where}";
			}
		}
		return $queryK2;
	}

    /**
     * Build query get list comment for article Easy Blog
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    static function getLatestFromEasyblog($params, $source)
    {
        $queryEb = '';
        if ($source[0] == '' || in_array('com_easyblog', $source)) {
			if (self::checkComponent('com_easyblog')) {
				// generate query for com_content
				$content_category = $params->get("type-com_content-eb_category", array());
				reset($content_category);
				$where = "cm4.type = 1";
				$where .= " AND cm4.option = 'com_easyblog'";
				$where .= " AND eb.published = 1";
				if (current($content_category)!="") {
					if (!is_array($content_category)) {
						$content_category = array($content_category);
					}

					if (count($content_category)) {
						$where .= " AND eb.category_id IN (" . implode(',', $content_category) . ")";
					}
				}

				$queryEb = "SELECT cm4.*, eb.title AS content_title FROM #__jacomment_items cm4"
							. "\n LEFT JOIN #__easyblog_post eb ON cm4.contentid = eb.id"
							. "\n WHERE {$where}";
			}
		}
        return $queryEb;
    }

    /**
     * Build query get list comment for article Joom Blog
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    static function getLatestFromJoomblog($params, $source)
    {
        $queryJb = '';
        if ($source[0] == '' || in_array('com_joomblog', $source)) {
			if (self::checkComponent('com_joomblog')) {
				// generate query for com_content
				$content_category = $params->get("type-com_content-jb_category", array());
				reset($content_category);
				$where = "cm5.type = 1";
				$where .= " AND cm5.option = 'com_joomblog'";
				$where .= " AND jb.state != -2 AND jb.state != 0";
				if (current($content_category)!="") {
					if (!is_array($content_category)) {
						$content_category = array($content_category);
					}

					if (count($content_category)) {
						$where .= " AND jbb.blog_id IN (" . implode(',', $content_category) . ")";
					}
				}

				$queryJb = "SELECT cm5.*, jb.title AS content_title FROM #__jacomment_items cm5"
							. "\n LEFT JOIN #__content jb ON cm5.contenttitle = jb.title"
							. "\n  INNER JOIN #__joomblog_blogs jbb ON jb.id = jbb.content_id"
							. "\n WHERE {$where}";
			}
		}
        return $queryJb;
    }

    /**
     * Build query get list comment for component joomla
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    static function getLatestFromComponent($params, $source, $order, $count)
    {
        $db = JFactory::getDBO();

        if (!is_array($source)) {
            $source = array($source);
        }

        $queryContent = modJACLatestItemsHelper::getLatestFromContent($params, $source);

		$queryK2 = modJACLatestItemsHelper::getLatestFromK2($params, $source);
		$queryEb = modJACLatestItemsHelper::getLatestFromEasyblog($params, $source);
		$queryJb = modJACLatestItemsHelper::getLatestFromJoomblog($params, $source);
		
		if ($queryK2 == '') {
			$unionK2 = '';
			$excludeK2 = '';
		}
		else {
			$unionK2 = " UNION ({$queryK2})";
			$excludeK2 = ", 'com_k2'";
		}
		
		if ($queryEb == '') {
			$unionEb = '';
			$excludeEb = '';
		}
		else {
			$unionEb = " UNION ({$queryEb})";
			$excludeEb = ", 'com_easyblog'";
		}

		if ($queryJb == '') {
			$unionJb = '';
			$excludeJb = '';
		}
		else {
			$unionJb = " UNION ({$queryJb})";
			$excludeJb = ", 'com_joomblog'";
		}
		
        $where = "cm1.type = 1";

        if ($source[0] == '') {
		// select all components
			$query = "(SELECT cm1.*, '' AS content_title FROM #__jacomment_items cm1 WHERE {$where} AND cm1.option NOT IN ('com_content' {$excludeK2} {$excludeEb} {$excludeJb}))
					  UNION ({$queryContent}) 
					  {$unionK2}
					  {$unionEb}
					  {$unionJb}
					  ";
		} else if (count($source) == 1 && $source[0] == 'com_content') {
            // only select com_content
            $query = $queryContent;
		} else if (count($source) == 1 && $source[0] == 'com_k2') {
		// only select com_k2
			$query = $queryK2;
		} else if (count($source) == 1 && $source[0] == 'com_easyblog') {
		// only select com_easyblog
			$query = $queryEb;
		} else if (count($source) == 1 && $source[0] == 'com_joomblog') {
		// only select com_joomblog
			$query = $queryJb;
        } else {
            // select some of components
		
            // remove component has category selection from source
			$source = array_diff($source, array('com_content', 'com_k2', 'com_easyblog', 'com_joomblog'));

			$query = "(SELECT cm1.*, '' AS content_title FROM #__jacomment_items cm1"
					. "\n WHERE {$where} AND cm1.option IN ('" . implode("','", $source) . "'))";

            if ($queryContent != '') {
                $query .= " UNION ({$queryContent})";
            }
			
			$query .= $unionK2 . $unionEb . $unionJb;
		}

        $query .= " ORDER BY {$order} DESC LIMIT " . intval($count);

        $db->setQuery($query);
        return $db->loadObjectList();
    }
	
	protected static function checkComponent($component)
	{
		$db = JFactory::getDBO();
		$query = " SELECT COUNT(*) FROM #__extensions as c WHERE c.element = '$component' AND c.enabled = 1";
		$db->setQuery($query);
		return $db->loadResult();
	}

    /*
	 * get avatar, author info, content, title
	 */
    static function parseItems($params, &$items)
    {
        $helperSub = new JACSmartTrim();
        $helperCom = new JACommentHelpers();
        $typeAvatar = 0;
        require_once (JPATH_BASE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
        $model = new JACommentModelComments();
        $typeAvatar = $model->getParamValue("layout", "type_avatar", 0);
        if (!$items)
            return;
        foreach ($items as &$item) {
            if ($params->get("showcontent", 1)) {
				if ($params->get("length", 50) == 0) {
					$item->comment = '';
				} else {
					//$item->comment = html_entity_decode($helper->replaceBBCodeToHTML($item->comment));
					$item->comment = html_entity_decode($helperCom->showComment($helperCom->replaceBBCodeToHTML($item->comment, $params->get("showbbcode", 1), 1), true, $params->get("showsmiles", 1),'100%'));
					$item->comment = $helperSub->mb_trim($item->comment, 0, $params->get("length", 50));
					$item->comment = str_replace('<p>', '', $item->comment);
					$item->comment = str_replace('</p>', '', $item->comment);
				}
            }

            if ($params->get("show_content_title", 1)) {
                $item->contenttitle = empty($item->content_title) ? $item->contenttitle : $item->content_title;
                $item->contenttitle = $helperSub->mb_trim($item->contenttitle, 0, $params->get("limit_content_title", 50));
            }
            if ($params->get("avatar", "1")) {
                $item->avatar = JACommentHelpers::getAvatar($item->userid, 1, $params->get("avatar_size", 32), $typeAvatar, $item->email);
            }
            $author_info = $params->get("show_author_info", 1);
            if ($author_info) {
                //show real name
                $userInfo = JFactory::getUser($item->userid);
                if ($userInfo->id == 0) {
                    if ($author_info == "3") {
                        $item->author_info = $item->email;
                    } else {
                        $item->author_info = $item->name;
                    }
                } else {
                    if ($author_info == "1") {
                        $item->author_info = $userInfo->name;
                    } else if ($author_info == "2") {
                        $item->author_info = $userInfo->username;
                    } else {
                        $item->author_info = $userInfo->email;
                    }
                }

                if ($item->website && stristr($item->website, 'http://') === FALSE) {
                    $item->author_info = "<a href='http://{$item->website}'/>" . $item->author_info . "</a>";
                } else {
                    $item->author_info = $item->author_info;
                }
            }
            if ($params->get("show_date", 1) == 2) {
                $item->date = $helperCom->generatTimeStamp(strtotime($item->date));
            } else {
				$createDay = date('d', strtotime($item->date));
				$createMonth = JText::_(strtoupper(date('F', strtotime($item->date)))."_SHORT");
				$createYear = date('Y', strtotime( $item->date));
				
				$item->date = $createDay . ' ' . $createMonth . ' ' . $createYear;
            }
            if ($params->get("showcommentcount", 1)) {
                $search = '';
                $search .= ' AND c.option="' . $item->option . '"';
                $search .= ' AND c.contentid=' . $item->contentid . '';

                $totalType = $model->getTotalByType($search);

                $item->commentcount = (int) array_sum($totalType);
            }

            if (strpos($item->referer, "http://") === false) {
				$url = explode('#jacommentid',$item->referer);
				$jacommentid = '';
				if(count($url)>1){
					$jacommentid = '#jacommentid'.$url[1];
				}
	            if($item->option=='com_content'){
					require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');
					$itemtcontent = JTable::getInstance('content');
					$itemtcontent->load($item->contentid);
					$slug = $itemtcontent->id.':'.$itemtcontent->alias;
					$item->referer = JRoute::_(ContentHelperRoute::getArticleRoute($slug, $itemtcontent->catid));
				}else if($item->option=='com_k2'){
					if (self::checkComponent('com_k2')) {
						JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2'.DS.'tables');
						require_once (JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'route.php');
						$itemk2 = JTable::getInstance('K2Item', 'Table');
						$itemk2->load($item->contentid);
						$categoryk2 = JTable::getInstance('K2Category', 'Table');
						$categoryk2->load($itemk2->catid);
						$item->referer = urldecode(JRoute::_(K2HelperRoute::getItemRoute($itemk2->id.':'.urlencode($itemk2->alias), $itemk2->catid.':'.urlencode($categoryk2->alias))));
					}
					else {
						$item = null;
					}
				}else{
					$item->referer = JRoute::_($url[0]);
				}
				if($jacommentid){
					if ($item) {
						$item->referer .= $jacommentid;
					}
				}
            }
        }
    }

    /*
	 *
	 */
    static function loadStyle($module)
    {
        $mainframe = JFactory::getApplication();
        //load style of module
        JHTML::stylesheet('modules/' . $module->module . '/assets/' . $module->module . '.css');

        require_once (JPATH_BASE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
        $model = new JACommentModelComments();
        $enableSmileys = $model->getParamValue("layout", "enable_smileys", 1);
        $smiley = $model->getParamValue("layout", "smiley", "default");
        if ($enableSmileys && !defined("JACOMMENT_GLOBAL_CSS_SMILEY")) {
			$style = '
					/* This is dynamic style for smiley */
			       #jac-wrapper .plugin_embed .smileys,.jac-mod_content .smileys{
			            top: 17px;
			        	background:#ffea00;
			            clear:both;
			            height:84px;
			            width:105px;
			            padding:2px 1px 1px 2px !important;
			            position:absolute;
			            z-index:51;
			            -webkit-box-shadow:0 1px 3px #999;box-shadow:1px 2px 3px #666;-moz-border-radius:2px;-khtml-border-radius:2px;-webkit-border-radius:2px;border-radius:2px;
			        }
			        #jac-wrapper .plugin_embed .smileys li,.jac-mod_content .smileys li{
			            display: inline;
			            float: left;
			            height:20px;
			            width:20px;
			            margin:0 1px 1px 0 !important;
			            border:none;
			            padding:0
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley,.jac-mod_content .smileys .smiley{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys_bg.png) no-repeat;
			            display:block;
			            height:20px;
			            width:20px;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley:hover,.jac-mod_content .smileys .smiley:hover{
			            background:#fff;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley span, .jac-mod_content .smileys .smiley span{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat;
			            display: inline;
			            float: left;
			            height:12px;
			            width:12px;
			            margin:0px;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley span span, .jac-mod_content .smileys .smiley span span{
			            display: none;
			        }
			        #jac-wrapper .comment-text .smiley {
			            font-family:inherit;
						font-size:100%;
						font-style:inherit;
						font-weight:inherit;
						text-align:justify;
			        }
			        #jac-wrapper .comment-text .smiley span, .jac-mod_content .smiley span{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat scroll 0 0 transparent;
						display:inline;
						float:left;
						height:12px;
						margin:0px 1px;
						width:12px;
			        }
			        .comment-text .smiley span span,.jac-mod_content .smiley span span{
			            display:none;
			        }
			';

		    $doc = JFactory::getDocument();
            $doc->addStyleDeclaration($style);
        }

        if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '.css')) {
            JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '.css');
        }

        $lang = JFactory::getLanguage();
        if ($lang->isRTL()) {
            if (file_exists(JPATH_BASE . DS . 'modules/mod_jaclatest_comments/assets/' . $module->module . '_rlt.css')) {
                JHTML::stylesheet('modules/mod_jaclatest_comments/assests/' . $module->module . '_rtl.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '_rtl.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '_rtl.css');
            }
        }

        if (!defined('JACOMMENT_GLOBAL_CSS')) {
            $theme = JACommentModelComments::getParamValue("layout", "themes", "default");
            $session = JFactory::getSession();

            if (JRequest::getVar("jacomment_theme", '')) {
                jimport('joomla.filesystem.folder');
                $themeURL = JRequest::getVar("jacomment_theme");

                if (JFolder::exists('components/com_jacomment/themes/' . $themeURL) || (JFolder::exists('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $themeURL))) {
                    $theme = $themeURL;
                }
                $session->set('jacomment_theme', $theme);
            } else {
                if ($session->get('jacomment_theme', null)) {
                    $theme = $session->get('jacomment_theme', $theme);
                }
            }
            //add style for japopup
            if (file_exists('components/com_jacomment/asset/css/ja.popup.css')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/ja.popup.css');
            }
            //override template for japopup in template
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.popup.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.popup.css');
            }

            //add style for all component
            if (file_exists('components/com_jacomment/asset/css/ja.comment.css')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/ja.comment.css');
            }
            //override for all component
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.comment.css');
            }

            //add style only IE for all component
            if (file_exists('components/com_jacomment/asset/css/ja.ie.php')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/ja.ie.php');
            }
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.ie.php')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.ie.php');
            }

            //add style of template for component
            if (file_exists('components/com_jacomment/themes/' . $theme . '/css/style.css')) {
                JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/style.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.css")) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/style.css');
            }

            if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style.ie.css')) {
                JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/style_ie.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.ie.css")) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/style.ie.css');
            }
            //override for all component
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.comment.css');
            }

            if ($lang->isRTL()) {
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.popup_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/ja.popup_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.popup_rtl.css')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.popup_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.comment_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/ja.comment_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment_rtl.css')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.comment_rtl.css');
                }

                //add style only IE for all component
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.ie_rtl.php')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/ja.ie.php');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.ie_rtl.php')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.ie_rtl.php');
                }

                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/style_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style_rtl.css")) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/style_rtl.css');
                }

                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style.ie_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/style_ie_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.ie_rtl.css")) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/style.ie_rtl.css');
                }
            }

            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.custom.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/ja.comment.custom.css');
            }

            define('JACOMMENT_GLOBAL_CSS', true);
        }
    }	
}