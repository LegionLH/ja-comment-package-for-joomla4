<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 

if (! class_exists('modJACLatestItemsJoomblogHelper')) {
    class modJACLatestItemsJoomblogHelper
    {
        /**
         * Get Joom Blog categories
		 * 
         * @return object List of Joom Blog categories
         */
        function getCategories()
        {
            $db = JFactory::getDBO();
			
			$query = 'SELECT `id` AS `id`, `title` AS `name`, 0 AS `parent` 
					  FROM #__joomblog_list_blogs WHERE published=1 AND private=0 ORDER BY create_date';
			$db->setQuery($query);
			
			return $db->loadObjectList();
        }
		
		/**
		 * Display comment list
		 * 
		 * @param string	$option Component name
		 * @param int		$print	In print mode or not
		 * @param string	$view	View layout
		 * 
		 * @return boolean Comment list can be showed or not
		 */
		function checkShowComments($option, $print, $view)
		{
			$show = JRequest::getCmd("show");
			return ($option == "com_joomblog" && $print == 0 && empty($view) && isset($show));
		}
		
		/**
		 * Get category id of an article
		 * 
		 * @param object	$article	Article object
		 * 
		 * @return int Category id
		 */
		function getArticleCategoryId($article)
		{
			$db = JFactory::getDBO();
			
			$query = "SELECT `blog_id` FROM #__joomblog_blogs WHERE `content_id` = {$article->id}";
			$db->setQuery($query);
			$blogId = $db->loadObjectList();
			
			return $blogId[0]->blog_id;
		}
    }
}
?>