<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 

if (! class_exists('modJACLatestItemsEasyblogHelper')) {
    class modJACLatestItemsEasyblogHelper
    {
        /**
         * Get Easy Blog categories
		 * 
         * @return object List of Easy Blog categories
         */
        function getCategories()
        {
            $db = JFactory::getDBO();
			
			$query = 'SELECT `id` AS `id`, `title` AS `name`, `parent_id` AS `parent` 
					  FROM #__easyblog_category WHERE published=1 ORDER BY parent_id, ordering';
			$db->setQuery( $query );
			
			return $db->loadObjectList();
        }
		
		/**
		 * Display comment list
		 * 
		 * @param string	$option Component name
		 * @param int		$print	In print mode or not
		 * @param string	$view	View layout
		 * 
		 * @return boolean Comment list can be showed or not
		 */
		function checkShowComments($option, $print, $view)
		{
			return ($option == "com_easyblog" && $print == 0 && $view == "entry");
		}
		
		/**
		 * Get category id of an article
		 * 
		 * @param object	$article	Article object
		 * 
		 * @return int Category id
		 */
		function getArticleCategoryId($article)
		{
			return $article->category_id;
		}
    }
}
?>