/**
 *$JA#COPYRIGHT$
 */
function insertJACommentOn(editor, editorContent) {
	var content = editorContent;						
	if (content.match(/{jacomment on}/)) {
		return false;
	} else {
		jInsertEditorText('{jacomment on}', editor);					
	}				
}