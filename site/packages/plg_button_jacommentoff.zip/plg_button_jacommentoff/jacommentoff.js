/**
 *$JA#COPYRIGHT$
 */
function insertJaCommentOn(editor, editorContent) {
	var content = editorContent;
	if (content.match(/{jacomment on}/)) {
		content.replace('{jacomment on}', '');
	}
	if (content.match(/{jacomment off}/)) {
		return false;
	} else {
		jInsertEditorText('{jacomment off}', editor);
	}
}