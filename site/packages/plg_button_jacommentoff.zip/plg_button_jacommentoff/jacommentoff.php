<?php
/**
 *$JA#COPYRIGHT$
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

// define directory separator short constant
if (!defined( 'DS' )) {
	define( 'DS', DIRECTORY_SEPARATOR );
}

if(!file_exists(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'jacomment.php')){
	return;	
}

jimport('joomla.event.plugin');
/**
 * Editor JAComment Off button plugin
 */
class plgButtonJaCommentOff extends JPlugin
{
	function plgButtonJCommentsOff(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}

	function onDisplay($name)
	{
		// ++ NhatNX 20110425
		// check if editor name is not correct
		// for JCE beta
		if (strpos($name, '[') !== false) {
			$name = str_replace('[', '_', $name);
			$name = str_replace(']', '', $name);
		}
		// -- NhatNX 20110425
		
		$doc = JFactory::getDocument();
		$getContent = $this->_subject->getContent($name);
		if (strrpos($getContent, ';') !== false)
			$getContent = substr($getContent, 0, -1);
		
		JHTML::script('plugins/editors-xtd/jacommentoff/jacommentoff.js');
		
		$button = new JObject();
		$button->set('modal', false);
		$button->set('onclick', 'insertJaCommentOn(\''.$name.'\', ' . $getContent . ');return false;');
		$button->set('text', 'JAComment OFF');
		$button->set('name', 'blank');
		$button->set('class', 'btn');
		$button->set('link', '#');

		return $button;
	}
}
?>