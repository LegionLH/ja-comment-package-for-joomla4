<?php
/**
 * $JA#COPYRIGHT$
 */

defined( '_JEXEC' ) or die( 'Restricted access' ); 

//jimport( 'joomla.plugin.plugin' );
//jimport( 'joomla.html.parameter' );
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

if (! defined('DS')) {
	define('DS',DIRECTORY_SEPARATOR);
}
/**
 * JAComment System Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.5
*/
class plgSystemSystem_JAComment extends JPlugin
{
	var $_plgCode 		= "#{jacomment(.*?) contentid=(.*?) option=(.*?) contenttitle=(.*?)}#i";
	var $_plgAddButton 	= "#{jacomment_addbutton(.*?) link=(.*?) contentid=(.*?)}#i";     
	var $_plgCount 		= "#{jacomment_count(.*?) contentid=(.*?) option=(.*?) contenttitle=(.*?)}#i";  
	var $_plgStart   	= "\n\n<!-- JAComment starts -->\n";
	var $_plgEnd     	= "\n<!-- JAComment ends -->\n\n";
	var $_plgCodeDisable= "#{jacomment(\s)off id=(.*?)}#i";
	var $_plgCodeEnable = "#{jacomment(.*?) contentid=(.*?) option=(.*?) contenttitle=(.*?)}#i";
	var $_option	 	= "com_content";	
	var $_print		 	= 0;
	var $_allow3rdComponents = array('com_k2', 'com_easyblog', 'com_joomblog');
	
	function __construct( &$subject ){
		parent::__construct( $subject );
		
		// load plugin parameters
		$this->plugin = JPluginHelper::getPlugin('system', 'system_jacomment');
		$this->plgParams = new JRegistry;
		$this->plgParams->loadString($this->plugin->params);
	}

	function check($_body=''){
		$app = Factory::getApplication(); 
		if ( $app->isClient('administrator') ) { return; }
		if (!isset($this->plugin)) return;
		if(!$_body)
		$_body = $app->getBody();
	   
		if ($this->plgParams->get ('disable', 0)) {
			$found = false;
		} else {
			//check if show plugin code
			$found = preg_match($this->_plgCode, $_body);         

			if ($found) {        	
				return $_body;   
			}
		
			//check if show plugin add button
			$found = preg_match($this->_plgAddButton, $_body);         
		}
		
		if ($found) {        	
			return $_body;
		}
	   
		$_body 	   = preg_replace("#{jacomment.*}#i", "", $_body);
		$app->setBody($_body);

		return false;
	}

	function onAfterRoute()
	{
		if(file_exists(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'jacomment.php')){

			$app = Factory::getApplication();

			if ( $app->isClient('administrator') ) { return; }

	                $inputs = Factory::getApplication()->input;

			$option         = $inputs->get('option', '');
			$print			= $inputs->get('print', 0);			
			$this->_option	= $option; 
			$this->_print	= $print;						

			if($option == 'com_content' || $print || in_array($option, $this->_allow3rdComponents)){				
				return;	
			}
	
			$doc = Factory::getDocument();

			if($option != 'com_content'){				
				//add style for all componennt
				$doc->addStyleSheet('components/com_jacomment/asset/css/ja.comment.css');
				//override for all component
				if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.comment.css')){
					$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.comment.css');
				}

				require_once(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'models'.DS.'comments.php');
				$model = new JACommentModelComments();
				$theme = $model->getParamValue( 'layout', 'theme' ,'default');
				$session = Factory::getSession();

				if($inputs->get("jacomment_theme", '')){
					jimport( 'joomla.filesystem.folder' );
					$themeURL = $inputs->get("jacomment_theme");
					if(JFolder::exists('components/com_jacomment/themes/'.$themeURL) || (JFolder::exists('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$themeURL))){
						$theme =  $themeURL;						
					}
					$session->set('jacomment_theme', $theme);			
				}else{
					if($session->get('jacomment_theme', null)){
						$theme = $session->get('jacomment_theme', $theme);
					}
				}					
																		
				if(!defined('JACOMMENT_GLOBAL_CSS')){																	 
					$app = Factory::getApplication();			      

					//add style for japopup
					if(file_exists('components/com_jacomment/asset/css/ja.popup.css')){			      
						$doc->addStyleSheet('components/com_jacomment/asset/css/ja.popup.css');
					}

					//override template for japopup in template
					if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.popup.css')){
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.popup.css');
					}

					//add style for all componennt
					if(file_exists('components/com_jacomment/asset/css/ja.comment.css')){
						$doc->addStyleSheet('components/com_jacomment/asset/css/ja.comment.css');
					}

					//override for all component
					if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.comment.css')){
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.comment.css');
					}
				
					//add style only IE for all component
					if(file_exists('components/com_jacomment/asset/css/ja.ie.php')){
						$doc->addStyleSheet('components/com_jacomment/asset/css/ja.ie.php');
					}            							

					if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.ie.php')){
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.ie.php');
					}					
				
					//add style of template for component
					if(file_exists('components/com_jacomment/themes/'.$theme.'/css/style.css')){					
						$doc->addStyleSheet('components/com_jacomment/themes/'.$theme.'/css/style.css');
					}

					if(file_exists(JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style.css")){		
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/style.css');	 
					}
					
					if(file_exists(JPATH_BASE.DS.'components/com_jacomment/themes/'.$theme.'/css/style.ie.css')){
						$doc->addStyleSheet('components/com_jacomment/themes/'.$theme.'/css/style_ie.css');
					}	

					if(file_exists(JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style.ie.css")){		
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/style.ie.css');	 
					}
					
					$lang = Factory::getLanguage();											
					if ( $lang->isRTL() ) {						
						if(file_exists(JPATH_BASE.DS.'components/com_jacomment/asset/css/ja.popup_rtl.css')){
							$doc->addStyleSheet('components/com_jacomment/asset/css/ja.popup_rtl.css');	
						}					

						if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.popup_rtl.css')){
							$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.popup_rtl.css');	
						}

						if(file_exists(JPATH_BASE.DS.'components/com_jacomment/asset/css/ja.comment_rtl.css')){						
							$doc->addStyleSheet('components/com_jacomment/asset/css/ja.comment_rtl.css');			
						}															

						if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.comment_rtl.css')){
							$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.comment_rtl.css');	
						}						

						//add style only IE for all component
						if(file_exists(JPATH_BASE.DS.'components/com_jacomment/asset/css/ja.ie_rtl.php')){
							$doc->addStyleSheet('components/com_jacomment/asset/css/ja.ie.php');            		
						}					

						if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.ie_rtl.php')){
							$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.ie_rtl.php');
						}											

						if(file_exists(JPATH_BASE.DS.'components/com_jacomment/themes/'.$theme.'/css/style_rtl.css')){
							$doc->addStyleSheet('components/com_jacomment/themes/'.$theme.'/css/style_rtl.css');
						}

						if(file_exists(JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style_rtl.css")){		
							$doc->addStyleSheet('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/style_rtl.css');	 
						}

						if(file_exists(JPATH_BASE.DS.'components/com_jacomment/themes/'.$theme.'/css/style.ie_rtl.css')){
							$doc->addStyleSheet('components/com_jacomment/themes/'.$theme.'/css/style_ie_rtl.css');
						}	

						if(file_exists(JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style.ie_rtl.css")){		
							$doc->addStyleSheet('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/style.ie_rtl.css');	 
						}
					}		
					
					$enableSmileys = $model->getParamValue( 'layout', 'enable_smileys' ,0);
					
					if($enableSmileys){
						$smiley = $model->getParamValue( 'layout', 'smiley' , 'default');
						$style = '
							#jac-wrapper .plugin_embed .smileys{
								top: 17px;
								background:#ffea00;
								clear:both;
								height:84px;
								width:105px;
								padding:2px 1px 1px 2px !important;
								position:absolute;
								z-index:51;
								-webkit-box-shadow:0 1px 3px #999;box-shadow:1px 2px 3px #666;-moz-border-radius:2px;-khtml-border-radius:2px;-webkit-border-radius:2px;border-radius:2px;
							}        
							#jac-wrapper .plugin_embed .smileys li{
								display: inline;
								float: left;
								height:20px;
								width:20px;
								margin:0 1px 1px 0 !important;
								border:none;
								padding:0 !important;
							}
							#jac-wrapper .plugin_embed .smileys .smiley{
								background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys_bg.png) no-repeat;
								display:block;
								height:20px;
								width:20px;
							}
							#jac-wrapper .plugin_embed .smileys .smiley:hover{
								background:#fff;
							}
							#jac-wrapper .plugin_embed .smileys .smiley span{
								background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat;
								display: inline;
								float: left;
								height:12px;
								width:12px;
								margin:0px;
							}
							#jac-wrapper .plugin_embed .smileys .smiley span span{
								display: none;
							} 
							#jac-wrapper .comment-text .smiley {
								font-family:inherit;
								font-size:100%;
								font-style:inherit;
								font-weight:inherit;
								text-align:justify;
							}
							.comment-text .smiley span{
								background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat scroll 0 0 transparent;
								display:inline;
								float:left;
								height:12px;
								margin:0px;
								width:12px;
							}
							.comment-text .smiley span span{
								display:none;
							}
						';																
						$doc = Factory::getDocument();
						$doc->addStyleDeclaration($style);
						define('JACOMMENT_GLOBAL_CSS_SMILEY', true);
					}

					if(file_exists(JPATH_BASE.DS.'templates/'.$app->getTemplate().'/css/ja.comment.custom.css')){
						$doc->addStyleSheet('templates/'.$app->getTemplate().'/css/ja.comment.custom.css');
					}

					define('JACOMMENT_GLOBAL_CSS', true);
				}
				
				// in some cases, your site loaded under ssl ( https ) and you will have warning because have link to non secured
				$scheme = str_replace('https', '', JURI::root());
				$scheme = str_replace('http', '', JURI::root());
				$uri = JURI::getInstance();
				$_root = $uri->getScheme() . $scheme;
				
				if(!defined('JACOMMENT_GLOBAL_JS')){					

					//load jquery
					if(version_compare(JVERSION, '3.0', 'ge')){
						$doc->getWebAssetManager()->useScript('jquery');
					} else {
						$scripts = $doc->_scripts;
						$jqueryIncluded = 0;
						if(is_array($scripts) && count($scripts)) {
							$pattern = '/jquery([-_]*\d+(\.\d+)+)?(\.min)?\.js/i';//is jquery core
							foreach ($scripts as $script => $opts) {
								if(preg_match($pattern, $script)) {
									$jqueryIncluded = 1;
								}
							}
						}
						
						if(!$jqueryIncluded) {
							$doc->addScript('components/com_jacomment/libs/bootstrap/js/jquery.js');
							$doc->addScript('components/com_jacomment/libs/js/jquery/jquery.noconflict.js');
						}
					}

					$doc->addScript($_root.'components/com_jacomment/asset/js/ja.comment.js');
					$doc->addScript($_root.'components/com_jacomment/asset/js/ja.popup.js');
					
					$doc->addScript($_root.'components/com_jacomment/asset/js/ja.mootools.js');
					
					if ($model->getParamValue('layout', 'enable_character_counter' ,0) == 1) {
						$doc->addScript($_root.'components/com_jacomment/libs/js/jquery/jquery.counter-2.2.min.js');
					}
					
					if ($model->getParamValue('layout', 'enable_location_detection' ,0) == 1) {
						$gmapKey = $model->getParamValue('layout', 'custom_location_detection', 'AIzaSyDyKVaBq39PW8Sjy0nxPMKB8lJd8Qjo1Sw');
						$doc->addScript('https://maps.googleapis.com/maps/api/js?v=3&libraries=places,adsense&sensor=true&key=' . $gmapKey);
						$doc->addScript($_root.'components/com_jacomment/asset/js/ja.location.js');
					}

					define('JACOMMENT_GLOBAL_JS', true);
				}			
				if(!defined('JACOMMENT_PLUGIN_ATD')){
					$doc->addStyleSheet('components/com_jacomment/asset/css/atd.css');
					$doc->addScript('components/com_jacomment/libs/js/atd/jquery.atd.js');
					$doc->addScript('components/com_jacomment/libs/js/atd/csshttprequest.js');
					$doc->addScript('components/com_jacomment/libs/js/atd/atd.js');											   
					define('JACOMMENT_PLUGIN_ATD', true);            
				}
			}
		}
	}

	function onBeforeRender(){
		if(version_compare(JVERSION, '4.0', '<')) {
			if(version_compare(JVERSION, '3.0', 'ge')){
				$doc = Factory::getDocument();
				$scripts = array();
				
				$jabtlink = defined('T3_URL') ? T3_URL.'/bootstrap/js/bootstrap.js' : JURI::root(true) .'/components/com_jacomment/libs/bootstrap/js/bootstrap.min.js';
	
				$t3bootstrap = false;
				$jabootstrap = false;
				foreach ($doc->_scripts as $url => $script) {
					if(strpos($url, $jabtlink) !== false){
						$t3bootstrap = true;
						if($jabootstrap){ //we already have the Joomla bootstrap and we also replace to T3 bootstrap
							continue;
						}
					}
	
					if(preg_match('@media/jui/js/bootstrap(.min)?.js@', $url)){
						if($t3bootstrap){ //we have T3 bootstrap, no need to add Joomla bootstrap
							continue;
						} else {
							$scripts[$jabtlink] = $script;
						}
	
						$jabootstrap = true;
					} else {
						$scripts[$url] = $script;
					}
				}
				
				if(!$t3bootstrap && !$jabootstrap){
					$doc->addScript($jabtlink);	
				} else {
					$doc->_scripts = $scripts;
				}
	
			}
		}
	}
	
	function replaceCommentCode($_body){				
		$option = $this->_option;
		if($option == 'com_content' || $this->_print || in_array($option, $this->_allow3rdComponents)){
			return;	
		}
		
		//check comment, also remove all jacomment placeholder if disabled		
		$_body = $this->check($_body);
		$inputs = Factory::getApplication()->input;

		if(file_exists(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'jacomment.php') && $option != "com_content"){			
			//global $app;
			$app = Factory::getApplication();
			if ( $app->isClient('administrator') ) { return; }				
			$tmpl = 'default';
			$plugin = $this->plugin;
			$plgParams = $this->plgParams;		
			require_once(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'models'.DS.'comments.php');					
			$model = new JACommentModelComments();			        			            						   														
			$theme = $model->getParamValue( 'layout', 'theme' , 'default');
			$session = Factory::getSession();
			if($inputs->get("jacomment_theme", '')){
				jimport( 'joomla.filesystem.folder' );
				$themeURL = $inputs->get("jacomment_theme",'');
				if(JFolder::exists('components/com_jacomment/themes/'.$themeURL) || (JFolder::exists('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$themeURL))){
					$theme =  $themeURL;						
				}
				$session->set('jacomment_theme', $theme);			
			}else{
				if($session->get('jacomment_theme', null)){
					$theme = $session->get('jacomment_theme', $theme);
				}
			}						

			if ($_body) {						    
				require_once (JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'helpers'.DS.'jahelper.php');
				$helper = new JACommentHelpers();

				//show button add new comment and count comment.
				if(strpos($_body, "jacomment_addbutton") || strpos($_body, "jacomment_count")){														
					preg_match_all($this->_plgAddButton, $_body, $matches);
					preg_match_all($this->_plgCount, $_body, $matchesCount);					
					preg_match_all($this->_plgCodeDisable, $_body, $matchesDisable);															
					
					JPlugin::loadLanguage( 'com_jacomment');
					
					$plugInType = "system";

					//change plugin button with button
					for($i =0 ; $i< count($matches[0]); $i++){							                							
						if(isset($matches[2][$i])){								
							$links = $matches[2][$i];
						}else{
							$links = "";
						}
						if(isset($matches[3][$i])){								
							$id = $matches[3][$i];
						}else{
							$id = "";
						}						

						$typeDisplay = "onlyButton"; 							
						ob_start ();						
						require $helper->jaLoadBlock("comments/getbutton.php", $theme);  		                
						$output = ob_get_contents();
						ob_end_clean(); 					                	                  			                  		    

						$_body = str_replace($matches[0][$i], $output, $_body);	                		                	

					}				
													
					//change plugin count with count
					for($i =0 ; $i< count($matchesCount[0]); $i++){							                							
						//get content id
						if(isset($matchesCount[2][$i])){								
							$id = $matchesCount[2][$i];
						}else{
							$id = "";
						}			
						//get content option
						if(isset($matchesCount[3][$i])){								
							$option = $matchesCount[3][$i];
						}else{
							$option = "";
						}								
						//get content title
						if(isset($matchesCount[4][$i])){								
							$title = addslashes($matchesCount[4][$i]);
						}else{
							$title = "";
						}
						
						$typeDisplay = "onlyCount"; 							
						ob_start ();
						require $helper->jaLoadBlock("comments/getbutton.php", $theme);             		                
						$output = ob_get_contents();
						ob_end_clean(); 					                	                  			                  		    

						$_body = str_replace($matchesCount[0][$i], $output, $_body);
												
					}

					if(count($matchesDisable[0])){
						$txtscript = '';

						for($i =0 ; $i< count($matchesDisable[0]); $i++){
							//get content id						
							$contentid = $matchesDisable[2][$i];
							$txtscript .= "$$('.jac-links".$contentid."').setStyle('display', 'none');";
							if($i < (count($matchesDisable[0])-1))
								$_body 	   = str_replace($matchesDisable[0][$i], "", $_body);							
						}						
						ob_start ();						
						echo '<script type="text/javascript">';
						echo '$(window).addEvent( "domready", function(){';						
						echo $txtscript; 												
						echo '});</script>';						
						$output = ob_get_contents();
						ob_end_clean();

						$i--;
						$_body 	   = str_replace($matchesDisable[0][$i], $output, $_body);
						//always remove eneable tag
						$_body 	   = preg_replace($this->_plgCodeEnable, "", $_body);
						$_body 	   = preg_replace("#{jacomment.*}#i", "", $_body);												
					}	
						$_body 	   = preg_replace($this->_plgCodeEnable, "", $_body);																
				}							        								
			}			
			if ( $_body ) {
				$_body 	   = preg_replace("#{jacomment.*}#i", "", $_body);								
			}  
			return $_body;
		}
	}
   
	function onAfterRender()
	{
		$option = $this->_option;
		if($option == 'com_content' || $this->_print || in_array($option, $this->_allow3rdComponents)){
				return;	
		}

		//check comment, also remove all jacomment placeholder if disabled
		$_body = $this->check();
		$inputs = Factory::getApplication()->input;

		if(file_exists(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'jacomment.php') && $option != "com_content"){			
			//global $app;
			$app = Factory::getApplication();
			if ( $app->isClient('administrator') ) { return; }
			$tmpl = 'default';
			$plugin = $this->plugin;
			$plgParams = $this->plgParams;
			require_once(JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'models'.DS.'comments.php');
			$model = new JACommentModelComments();			        			            						   														
			$theme = $model->getParamValue( 'layout', 'theme' , 'default');
			$session = Factory::getSession();
			if($inputs->get("jacomment_theme", '')){
				jimport( 'joomla.filesystem.folder' );
				$themeURL = $inputs->get("jacomment_theme",'');
				if(JFolder::exists('components/com_jacomment/themes/'.$themeURL) || (JFolder::exists('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$themeURL))){
					$theme =  $themeURL;						
				}
				$session->set('jacomment_theme', $theme);			
			}else{
				if($session->get('jacomment_theme', null)){
					$theme = $session->get('jacomment_theme', $theme);
				}
			}
			if ($_body) { 			    
				require_once (JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'helpers'.DS.'jahelper.php');
				$helper = new JACommentHelpers();
				
				// in some cases, your site loaded under ssl ( https ) and you will have warning because have link to non secured
				$scheme = str_replace('https', '', JURI::root());
				$scheme = str_replace('http', '', JURI::root());
				$uri = JURI::getInstance();
				$_root = $uri->getScheme() . $scheme;

				//show button add new comment and count comment.
				if(strpos($_body, "jacomment_addbutton") || strpos($_body, "jacomment_count")){	

					preg_match_all($this->_plgAddButton, $_body, $matches);
					preg_match_all($this->_plgCount, $_body, $matchesCount);					
					preg_match_all($this->_plgCodeDisable, $_body, $matchesDisable);

					JPlugin::loadLanguage( 'com_jacomment');

					$plugInType = "system";

					//change plugin button with button
					for($i =0 ; $i< count($matches[0]); $i++){							                							
						if(isset($matches[2][$i])){								
							$links = $matches[2][$i];
						}else{
							$links = "";
						}
						if(isset($matches[3][$i])){								
							$id = $matches[3][$i];
						}else{
							$id = "";
						}						
						$typeDisplay = "onlyButton"; 							
						ob_start ();						
						require $helper->jaLoadBlock("comments/getbutton.php", $theme);  		                
						$output = ob_get_contents();
						ob_end_clean(); 					                	                  			                  		    		               
						$_body = str_replace($matches[0][$i], $output, $_body);
					}				
					//change plugin count with count
					for($i =0 ; $i< count($matchesCount[0]); $i++){							                							
						//get content id
						if(isset($matchesCount[2][$i])){								
							$id = $matchesCount[2][$i];
						}else{
							$id = "";
						}			
						//get content option
						if(isset($matchesCount[3][$i])){								
							$option = $matchesCount[3][$i];
						}else{
							$option = "";
						}								
						//get content title
						if(isset($matchesCount[4][$i])){								
							$title = addslashes($matchesCount[4][$i]);
						}else{
							$title = "";
						}

						$typeDisplay = "onlyCount"; 							
						ob_start ();
						require $helper->jaLoadBlock("comments/getbutton.php", $theme);             		                
						$output = ob_get_contents();
						ob_end_clean(); 					                	                  			                  		    
						 
						$_body = str_replace($matchesCount[0][$i], $output, $_body);
					}
					//disable - button
					if(count($matchesDisable[0])){
						$txtscript = '';						
						for($i =0 ; $i< count($matchesDisable[0]); $i++){
							//get content id						
							$contentid = $matchesDisable[2][$i];
							$txtscript .= "$$('.jac-links".$contentid."').setStyle('display', 'none');";
							if($i < (count($matchesDisable[0])-1))
								$_body 	   = str_replace($matchesDisable[0][$i], "", $_body);							
						}						
						ob_start ();					
						echo '<script type="text/javascript">';
						echo '$(window).addEvent( "domready", function(){';					
						echo $txtscript; 						
						echo '});</script>';						
						$output = ob_get_contents();
						ob_end_clean();
						$i--;
						$_body 	   = str_replace($matchesDisable[0][$i], $output, $_body);
						//always remove eneable tag
						$_body 	   = preg_replace($this->_plgCodeEnable, "", $_body);
						$_body 	   = preg_replace("#{jacomment.*}#i", "", $_body);												
					}	
						$_body 	   = preg_replace($this->_plgCodeEnable, "", $_body);																
				}
				//show all comment of this items when call
				else{										
					if(preg_match($this->_plgCodeDisable, $_body)) {					
						$_body = preg_replace("#{jacomment.*}#i", "", $_body);						
						$app->setBody( $_body );
						return true;
					}
					//always remove eneable tag
					ob_start ();											
					$session = Factory::getSession();
					// Put a value in a session var
					$s = empty($_SERVER["HTTPS"]) ? '' : "s";
					$protocol = substr(strtolower($_SERVER["SERVER_PROTOCOL"]),0, strpos(strtolower($_SERVER["SERVER_PROTOCOL"]), "/")).$s;
					$port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
					$webUrl = $protocol."://".$_SERVER['SERVER_NAME'].$port.$_SERVER['REQUEST_URI'];				                                                                  
					$url = $app->isClient('administrator') ? $app->getSiteURL() : JURI::base();
					//if don't search juri root in current url
					if(strpos($webUrl, $url) === false){
						$url = str_replace("https", "http", $url);	
					}					
					$webUrl = JRoute::_(str_replace($url,"",$webUrl));					
					if(substr($webUrl,0,1) == "/"){
						$webUrl 	=	substr($webUrl,1);
					}	
					$session->set('commenturl', $webUrl);                                                 															
					$GLOBALS['jacconfig'] = array(); 
					JACommentHelpers::get_config_system();
					
					global $jacconfig;

					if(isset($jacconfig['general']) && $jacconfig['general']->get('is_comment_offline', 0)){
						$text_offline = "";
						if(!JACommentHelpers::check_access($text_offline)){
							$_body = preg_replace("#{jacomment.*}#i", $text_offline, $_body);						
							$app->setBody( $_body ); 
							return ;
						}
					}										

					require_once (JPATH_SITE.DS.'components'.DS.'com_jacomment'.DS.'helpers'.DS.'config.php');
					preg_match_all($this->_plgCode, $_body, $matches);						
					$lists['commenttype'] 	= 1;
					if(isset($matches[3][0])){								
						$lists['contentoption'] = $matches[3][0];
					}else{
						$lists['contentoption'] = '';
					}
					if(isset($matches[2][0])){
						$lists['contentid'] 	= $matches[2][0];	
					}else{
						$lists['contentid'] 	= 0;
					}

					if(isset($matches[4][0])){						
						$lists['contenttitle']  = addslashes($matches[4][0]);                                    						
					}else{
						$lists['contenttitle']  = "";
					}				
					$lists['jacomentUrl'] 	= $webUrl;								
					?>
					<!-- BEGIN - load blog head -->
					<?php require_once $helper->jaLoadBlock("comments/head.php");	?>
					<!-- END   - load blog head -->
					<?php if(($jacconfig['layout']->get('enable_addthis')==1) || ($jacconfig['layout']->get('enable_addtoany')==1) || ($jacconfig['layout']->get('enable_tweetmeme')==1)){	?>	 	   	
						  <div id="jac-social-links">
							<ul>
								<?php							
									if($jacconfig['layout']->get('enable_addthis')==1)												        	
										echo "<li>" .$jacconfig['layout']->get('custom_addthis'). "</li>";
									if($jacconfig['layout']->get('enable_addtoany')==1)	
										echo "<li>" .$jacconfig['layout']->get('custom_addtoany'). "</li>";		       
									if($jacconfig['layout']->get('enable_tweetmeme')==1)
										echo "<li>" .$jacconfig['layout']->get('custom_tweetmeme'). "</li>";
								?>
							</ul>
						  </div>	  
					<?php }?>
					<div id="jac-wrapper" class="clearfix"></div>		
					<script language="javascript">
					<![CDATA[
					<?php if (version_compare(JVERSION, '3.0', 'ge')): ?>
					$jaCmt = jQuery;
					<?php endif; ?>
					$jaCmt(document).ready(function() {
					$jaCmt = jQuery.noConflict();
					var url = window.location.hash;
					c_url = url.split('#');
					id = 0;
					tmp = 0;
					if(c_url.length >= 1){		
						for(i=1; i< c_url.length; i++){			
							if(c_url[i].indexOf("jacommentid:") >-1){				
								tmp = c_url[i].split(':')[1];				
								if(tmp != ""){									
									id = parseInt(tmp, 10);
								}
							}
						}
					}
					url = "<?php echo JRoute::_("index.php?tmpl=component&option=com_jacomment&view=comments&contentoption=$option&contentid={$lists['contentid']}&ran=".rand()) ?>";
					if(id != 0){
						url += "&currentCommentID=" + id;
					}
					$jaCmt.ajax({
						method: 'get',
						url: url,
						success: function(text) {
							$jaCmt('#jac-wrapper').html( $jaCmt('#jac-wrapper').html() + text);
							
							moveBackground(id, '<?php echo $_root;?>');
							jac_auto_expand_textarea();
							if($jaCmt('.conversation-avatar').length > 0){
								$jaCmt('.conversation-avatar').tooltip();
							}
							<?php if ($enableCharacterCounter) { ?>
							$jaCmt('.form-character-count').popover({placement:'top'});
							
							$jaCmt('#newcomment').counter({
								count: 'up', 
								goal: <?php echo $maxLength; ?>,
								msg: '&nbsp;/&nbsp;<?php echo $maxLength; ?>'
							});
							$jaCmt('#newcomment_counter').appendTo('.form-character-count');
							<?php } ?>
							
							<?php if ($enableLocationDetection) { ?>
							JALocation.initialize();
							$jaCmt(function() {
								// Setup drop down menu
								$jaCmt('.dropdown-toggle').dropdown();

								// Fix input element click problem
								$jaCmt('.dropdown input, .dropdown label, .dropdown button').click(function(e) {
									e.stopPropagation();
								});
							});
							<?php } ?>
							
							$jaCmt('#jacTab a:last').on('click', function (e) {
								displayVotedComments('<?php echo $option; ?>', '<?php echo $lists['contentid']; ?>');
							});
						}
					});
				 });
					]]>				
					</script>
				<?php 
					$output = ob_get_contents();
					ob_end_clean(); 					
					$output = $this->_plgStart.$output.$this->_plgEnd; 
					$_body = preg_replace($this->_plgCode, $output, $_body);
				}?>
			<?php            									
			}			
			if ( $_body ) {
				$_body 	   = preg_replace("#{jacomment.*}#i", "", $_body);				
				$app->setBody( $_body );
			}  
			return true;
		}
	}        
}
?>