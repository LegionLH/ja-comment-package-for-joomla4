<?php
/**
 *$JA#COPYRIGHT$
 */
// no direct access
defined('_JEXEC') or die ('Restricted access');

jimport('joomla.filesystem.folder');
$files = JFolder::files(dirname(__FILE__) . DS . '..' . DS . 'adapters');
if ($files) {
	foreach ($files as $file) {
		//only load php files
		if (strpos($file, ".php")) {
			require_once(dirname(__FILE__) . DS . '..' . DS . 'adapters' . DS . $file);
		}
	}
}

class JFormFieldJacategory extends JFormField
{
    /**
     * @access private
     */
	protected	$_name = 'jacategory';

	protected function getInput() {
		$controlId = str_replace('[', '', $this->name);
		$controlId = str_replace(']', '', $controlId);
		
		$comName = $this->element['component'];
		$comName = str_replace('com_', '', $comName);
		
		$comLangName = strtoupper($comName);

		if (! $this->checkComponent('com_' . $comName)) {
			return '<input type="hidden" name="' . $this->name . '[]" id="' . $controlId . '" value="" /> <span style="color:red; float:left">' . JText::_($comLangName . "_COMPONENT_IS_NOT_INSTALLED") . '</span>';
		}
		
		$comHelperCls = 'JAComment' . ucfirst($comName) . 'Helper';
		$mitems = null;
		if (class_exists($comHelperCls)) {
			$obj = new $comHelperCls;
			if (!method_exists($comHelperCls, 'getCategories')) {
				return '<input type="hidden" name="' . $this->name . '[]" id="' . $controlId . '" value="" /> <span style="color:red; float:left">' . JText::_("PLEASE_CREATE_METHOD_TO_GET_" . $comLangName . "_CATEGORY") . '</span>';
			} else {
				$mitems = $obj->getCategories();
			}
		}
		
		$children = array();
		if ($mitems) {
			foreach ( $mitems as $v ) {
				$v->parent_id = $v->parent;
				$v->title = $v->name;
				if(isset($children[$v->parent])) {
					$children[$v->parent][] = $v;
				} else {
					$children[$v->parent] = array($v);
				}
			}
		} else {
			return '<input type="hidden" name="' . $this->name . '[]" id="' . $controlId . '" value="" /> <span style="color:red; float:left">' . JText::_("PLEASE_INSERT_" . $comLangName . "_CATEGORY") . '</span>';
		}
		
		$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );
		$mitems = array();
		$mitems[] = JHTML::_('select.option', '', JText::_('JOPTION_ALL_CATEGORIES_' . $comLangName));
		foreach ( $list as $item ) {
			$item->treename = str_replace('- ', '', $item->treename);
			$item->treename = str_replace('&#160;&#160;', '- ', $item->treename);
			$mitems[] = JHTML::_('select.option',  $item->id, $item->treename);
		}
		
		$value = $this->value ? $this->value : (string)$this->element['default'];
		
		$output= JHTML::_('select.genericlist',  $mitems, $this->name . '[]', 
						'multiple="multiple" size="10"', 'value', 'text', $value );
		return $output;
	}
	
	protected function checkComponent($component)
	{
		$db = JFactory::getDBO();
		$query = " SELECT Count(*) FROM #__extensions as c WHERE c.element = '$component' AND c.enabled = 1";
		$db->setQuery($query);
		return $db->loadResult();
	}
}