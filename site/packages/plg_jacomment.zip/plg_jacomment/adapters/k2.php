<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 

if (! class_exists('JACommentK2Helper')) {
    class JACommentK2Helper
    {
        /**
         * Get K2 categories
		 * 
         * @return object List of K2 categories
         */
        function getCategories()
        {
            $db = JFactory::getDBO();
			
			$query = 'SELECT `id`, `name`, `parent` 
					  FROM #__k2_categories WHERE published=1 AND trash = 0 ORDER BY parent, ordering';
			$db->setQuery( $query );
			
			return $db->loadObjectList();
        }
		
		/**
		 * Display comment list
		 * 
		 * @param string	$option Component name
		 * @param int		$print	In print mode or not
		 * @param string	$view	View layout
		 * 
		 * @return boolean Comment list can be showed or not
		 */
		function checkShowComments($option, $print, $view)
		{
			return ($option == "com_k2" && $print == 0 && $view == "item");
		}
    }
}
?>