<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

/*function onK2AfterDisplay(&$row, &$params, $limitstart=1)
{
	$app = Factory::getApplication();
	if ( $app->isClient('administrator') ) { return; }

	if(!file_exists(JPATH_SITE."/components/com_jacomment/jacomment.php")){
		return "";
	}

	$inputs = Factory::getApplication()->input;
	$option	= $inputs->getCmd('option');
	$plgComment = plgContentJAComment::getInstance();

	//check category allow show comment
	$showComment = $plgComment->checkShowComment($row, $option);
	if($showComment){
		$plgComment->removeShortcode($row);
		return $plgComment->displayComment($row, $option);
	} else {
		return '';
	}
}

JDispatcher::getInstance()->register('onK2AfterDisplay', 'onK2AfterDisplay');*/