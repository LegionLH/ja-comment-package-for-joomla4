<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 

if (! class_exists('JACommentContentHelper')) {
    class JACommentContentHelper
    {
        /**
         * Get content categories
		 * 
         * @return object List of content categories
         */
        function getCategories()
        {
            $db = JFactory::getDBO();
			
			$query = 'SELECT `id`, `title` AS `name`, `parent_id` AS `parent` 
					  FROM #__categories WHERE published=1 ORDER BY parent_id, ordering';
			$db->setQuery( $query );
			
			return $db->loadObjectList();
        }
		
		/**
		 * Display comment list
		 * 
		 * @param string	$option Component name
		 * @param int		$print	In print mode or not
		 * @param string	$view	View layout
		 * 
		 * @return boolean Comment list can be showed or not
		 */
		function checkShowComments($option, $print, $view)
		{
			return ($option == "com_content" && $print == 0 && $view == "article");
		}
    }
}
?>