<?php
/**
 * $JA#COPYRIGHT$
 */
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\CMS\Factory;

jimport('joomla.plugin.plugin');
// jimport ('joomla.application.component.model');

if (! defined('DS')) {
	define('DS',DIRECTORY_SEPARATOR);
}

jimport('joomla.filesystem.folder');
$files = JFolder::files(dirname(__FILE__) . '/adapters');
if ($files) {
	foreach ($files as $file) {
		//only load php files
		if (strpos($file, ".php")) {
			require_once(dirname(__FILE__) . '/adapters/' . $file);
		}
	}
}

/**
 * JAComment Content plugin
 */
class plgContentJAComment extends JPlugin
{
	static $_instance			= null;

	var $_allow3rdComponents	= array('com_k2','com_easyblog', 'com_joomblog');
	var $_allow3rdComponents2  = array('com_easyblog', 'com_joomblog');
	var $_plgCode 				= "#{JAComment(.*?)}#i";
	var $_plgCodeDisable 		= "#{jacomment(\s)off.*}#i";
	var $_plgCodeEnable 		= "#{jacomment(\s)on.*}#i";
	var $_plgStart   			= "\n\n<!-- JAComment starts -->\n";
	var $_plgEnd     			= "\n<!-- JAComment ends -->\n\n";
	var $isEnabledComment		= 0;
	var $plgParams				= '';
	var $html 					= '';

	//: {jacomment contentid=xx option=xxxxx contentittle=''}
	function __construct( &$subject, $config )
	{
		parent::__construct( $subject, $config );
		$this->plugin = JPluginHelper::getPlugin('content', 'jacomment');

		self::$_instance = $this;

		$params = new JRegistry;
		$params->loadString($this->plugin->params);
		$this->plgParams  = $params;

		// load all triggers files
		$files = JFolder::files(dirname(__FILE__) . '/adapters/triggers');
		if ($files) {
			foreach ($files as $file) {
				//only load php files
				if (strpos($file, ".php")) {
					require_once(dirname(__FILE__) . '/adapters/triggers/' . $file);
				}
			}
		}
	}

	static function getInstance() { return self::$_instance; }

	//display top of content
	function onContentBeforeDisplay($context, &$row, &$params, $page=0)
	{
		$app = Factory::getApplication();
		if ( $app->isClient('administrator') ) {
			return;
		}
		if(!file_exists(JPATH_SITE.'/components/com_jacomment/jacomment.php')){
			return '';
		}

		$inputs = Factory::getApplication()->input;
		$option = $inputs->getCmd('option');
		if ($option == 'com_jak2filter') $option = 'com_k2';
		$plgParams = $this->plgParams;
		$this->isEnabledComment = $this->checkShowComment($row, $option);

		if($plgParams->get('postion_add_button', 'onContentBeforeDisplay') == "onContentBeforeDisplay" && $this->isEnabledComment) {
			$this->removeShortcode($row);
			return $this->showButton($row);
		} else {
			//$this->removeShortcode($row);
			return '';
		}
	}

	public function onAfterDisplayContent(&$row, &$params, $limitstart=1)
	{
		// USE ONLY FOR JOOM BLOG COMPONENT
		$app = Factory::getApplication();
		if ( $app->isClient('administrator') ) {
			return;
		}
		if(!file_exists(JPATH_SITE.'/components/com_jacomment/jacomment.php')){
			return '';
		}

		$option = 'com_joomblog';//JRequest::getCmd('option');
		$inputs = Factory::getApplication()->input;
		$print	= $inputs->getCmd('print', 0);
		$view = $inputs->getCmd("view");

		$plgParams = $this->plgParams;
		$this->isEnabledComment = $this->checkShowComment($row, $option);

		if($this->isEnabledComment) {
			$comName = str_replace('com_', '', $option);

			$comHelperCls = 'JAComment' . ucfirst($comName) . 'Helper';
			if(class_exists($comHelperCls)) {
				$obj = new $comHelperCls;
				if ($obj->checkShowComments($option, $print, $view)) {
					$this->removeShortcode($row);
					return $this->displayComment($row, $option);
				}
			}

			if($plgParams->get('postion_add_button', 'onContentBeforeDisplay') == "onContentAfterDisplay") {
				$this->removeShortcode($row);
				return $this->showButton($row);
			}
		} else {
			//$this->removeShortcode($row);
			return '';
		}
	}

	public function onContentAfterDisplay($context, &$row, &$params, $limitstart=1)
	{
		$app = Factory::getApplication();
		if ( $app->isClient('administrator') ) {
			return;
		}
		if(!file_exists(JPATH_SITE.'/components/com_jacomment/jacomment.php')){
			return '';
		}

		$inputs = Factory::getApplication()->input;
		$option = $inputs->getCmd('option');
		if ($option == 'com_jak2filter') $option = 'com_k2';
		$print	= $inputs->getCmd('print', 0);
		$view = $inputs->getCmd("view");
		$plgParams = $this->plgParams;
		$this->isEnabledComment = $this->checkShowComment($row, $option);

		if($this->isEnabledComment) {
			$comName = str_replace('com_', '', $option);

			$comHelperCls = 'JAComment' . ucfirst($comName) . 'Helper';
			if(class_exists($comHelperCls)) {
				$obj = new $comHelperCls;
				if ($obj->checkShowComments($option, $print, $view)) {
					$this->removeShortcode($row);
					return $this->displayComment($row, $option);
				}
			}

			if($plgParams->get('postion_add_button', 'onContentBeforeDisplay') == "onContentAfterDisplay") {
				$this->removeShortcode($row);
				return $this->showButton($row);
			}
		} else {
			//$this->removeShortcode($row);
			return '';
		}
	}

	public function onContentAfterTitle($context, &$row, &$params, $limitstart=1)
	{
		$app = Factory::getApplication();
		if ( $app->isClient('administrator') ) {
			return;
		}
		if(!file_exists(JPATH_SITE.'/components/com_jacomment/jacomment.php')){
			return '';
		}

		$inputs = Factory::getApplication()->input;
		$option = $inputs->getCmd('option');
		if ($option == 'com_jak2filter') $option = 'com_k2';
		$plgParams = $this->plgParams;
		$this->isEnabledComment = $this->checkShowComment($row, $option);

		if($plgParams->get('postion_add_button', 'onContentBeforeDisplay') == "onContentAfterTitle" && $this->isEnabledComment) {
			$this->removeShortcode($row);
			return $this->showButton($row);
		} else {
			//$this->removeShortcode($row);
			return '';
		}
	}


	function getParamValue($group, $param, $default){
		require_once(JPATH_BASE.'/components/com_jacomment/models/comments.php');
		$model = new JACommentModelComments();
		$paramValue = $model->getParamValue( $group, $param ,$default);
		return $paramValue;
	}

	function getLinkButton($fileName){
		$app = Factory::getApplication();
		$templateJaName = $this->getParamValue('layout', 'theme' , 'default');

		$templateDirectory  =  JPATH_BASE.'/templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$templateJaName."/html";
		if(file_exists($templateDirectory.'/'.$fileName)){
			return $templateDirectory.'/'.$fileName;
		}else{
			if(file_exists('components/com_jacomment/themes/'.$templateJaName.'/html/'.$fileName)){
				return 'components/com_jacomment/themes/'.$templateJaName.'/html/'.$fileName;
			}else{
				return 'components/com_jacomment/themes/default/html/'.$fileName;
			}
		}
	}

	//get text button
	function showButton($article)
	{
		$app = Factory::getApplication();
		if(!file_exists(JPATH_SITE.'/components/com_jacomment/jacomment.php')){
			return '';
		}

		$plugin 	= $this->plugin;
		$plgParams 	= $this->plgParams;
		$content 	= "";

		$id             = $article->id;
		$inputs = Factory::getApplication()->input;
		$option         = $inputs->getCmd('option');
		if ($option == 'com_jak2filter') $option = 'com_k2';
		$view           = $inputs->getCmd('view');

		$theme   = $this->getParamValue('layout', 'theme' , 'default');

		if ($plgParams->get("source", "all") != 'all' && $plgParams->get("source", "all") != $option) {
			return '';
		}

		$session = Factory::getSession();
		if($inputs->get("jacomment_theme", '')){
			jimport( 'joomla.filesystem.folder' );
			$themeURL = $inputs->get("jacomment_theme",'');
			if(JFolder::exists('components/com_jacomment/themes/'.$themeURL) || JFolder::exists('templates/'.$app->getTemplate().'html/com_jacomment/themes/'.$themeURL)){
				$theme =  $themeURL;
			}
			$session->set('jacomment_theme', $theme);
		}else{
			if($session->get('jacomment_theme', null)){
				$theme = $session->get('jacomment_theme', $theme);
			}
		}

		$links = $this->getLink($article);
		JPlugin::loadLanguage( 'com_jacomment', JPATH_SITE);

		if($links != ""){
			ob_start ();
			require $this->getLinkButton("comments/getbutton.php");
			$content = ob_get_contents ();
			ob_end_clean ();
		}

		return $content;
	}

	//check allow show comment in a category
	function checkShowComment(&$article, $option)
	{
		static $aCheck = array();
		if(isset($aCheck[$article->id])) {
			return $aCheck[$article->id];
		}
		$inputs = Factory::getApplication()->input;
		$print = $inputs->getCmd('print', 0);
		if (($option != "com_content" && ! in_array($option, $this->_allow3rdComponents)) || $print > 0){
			$this->removeShortcode($article);
			return false;
		}

		$comName = str_replace('com_', '', $option);
		$comHelperCls = 'JAComment' . ucfirst($comName) . 'Helper';
		$obj = new $comHelperCls;
		if (in_array($option, $this->_allow3rdComponents) && method_exists($comHelperCls, 'getArticleCategoryId')) {
			$article->catid = $obj->getArticleCategoryId($article);
		}

		$plgParams = $this->plgParams;
		$control_comments = $plgParams->get('control_comments',1);
		if($control_comments==1) {
			//Auto
			//If set to auto, the JA comment plugin will add the commenting feature by default, to the selected categories below.
			$check = true;

			$catid          = $article->catid;
			$id             = $article->id;
			$view           = $inputs->getCmd('view');
			$show           = $inputs->getCmd('show');
			$itemid         = $inputs->get('Itemid','');

			if ($option != "com_content" && ! in_array($option, $this->_allow3rdComponents)){
				$check = false;
			}

			if(!$article->id) {
				$check = false;
			}

			if (! isset($article->text)) {
				$db	= Factory::getDBO();
				$query = "SELECT `fulltext` FROM #__content WHERE id = '{$article->id}'";
				$db->setQuery($query);
				$article->text = $db->loadResult();
			}

			$catsid = $plgParams->get('catsid','');
			if ($option == "com_content") {
				self::checkShowCommentCatId($check, $catsid, $catid, $this->_plgCodeEnable, $this->_plgCodeDisable, $article);
			}

			// check if comment form is displayed or not
			if (in_array($option, $this->_allow3rdComponents)) {
				$comCatsId = $comName . "catsid";
				$comCatsId = $plgParams->get($comCatsId, '');

				self::checkShowCommentCatId($check, $comCatsId, $catid, $this->_plgCodeEnable, $this->_plgCodeDisable, $article);
			}

			$menusid = $plgParams->get('menusid','');
			if($menusid){
				if(!in_array($itemid, $menusid)){
					$check = false;
				}
			}

		} else {
			//Manual check
			//If set to manual, then you would need to add Comment on tag in each article, to enable the commenting feature for it.
			$check = false;
		}

		//check {comment off} code
		if(isset($article->text) && preg_match($this->_plgCodeDisable, $article->text)) {
			$check = false;
		} elseif(isset($article->introtext) && preg_match($this->_plgCodeDisable, $article->introtext)) {
			$check = false;
		} elseif(isset($article->fulltext) && preg_match($this->_plgCodeDisable, $article->fulltext)) {
			$check = false;
		}

		//check {comment on} code
		if(isset($article->text) && preg_match($this->_plgCodeEnable, $article->text)) {
			$check = true;
		} elseif(isset($article->introtext) && preg_match($this->_plgCodeEnable, $article->introtext)) {
			$check = true;
		} elseif(isset($article->fulltext) && preg_match($this->_plgCodeEnable, $article->fulltext)) {
			$check = true;
		}

		if(!$check) {
			$this->removeShortcode($article);
		}

		$aCheck[$article->id] = $check;
		return $check;
	}

	/**
	 * Check if comment form is displayed or not based on category id
	 *
	 * @param int 		$comCatsId 		Component category ids
	 * @param string	$enableCode		Enable code string
	 * @param string	$disableCode	Disable code string
	 * @param object	$article		Article object
	 *
	 * @return boolean True if comment form can be displayed, False if otherwise
	 */
	function checkShowCommentCatId(&$check, $comCatsId, $curCatId, $enableCode, $disableCode, $article)
	{
		if($comCatsId) {
			if ($comCatsId[0] == '') {
				// select all categories
				if(isset($article->text) && preg_match($disableCode, $article->text)) {
					$check = false;
				}
				if(isset($article->introtext) && preg_match($disableCode, $article->introtext)) {
					$check = false;
				}
			}
			else if (! in_array($curCatId, $comCatsId)) {
				$check = false;

				if(isset($article->text) && preg_match($enableCode, $article->text)) {
					$check = true;
				}
				if(isset($article->introtext) && preg_match($enableCode, $article->introtext)) {
					$check = true;
				}

			}
		} else {
			$check = false;
			if(isset($article->text) && preg_match($enableCode, $article->text)) {
				$check = true;
			}
			if(isset($article->introtext) && preg_match($enableCode, $article->introtext)) {
				$check = true;
			}
		}
	}

	//get link of comment
	function getLink($article)
	{
		$inputs = Factory::getApplication()->input;
		$option         = $inputs->getCmd('option');
		if ($option == 'com_jak2filter') $option = 'com_k2';
		$view           = $inputs->getCmd('view');
		$link = "";

		if ($option=='com_content' && ($view=='frontpage' || $view=='featured' || $view=='section' || $view=='category') && !isset($article->extra_fields)) {
			$user = Factory::getUser();
			$aid = max($user->getAuthorisedViewLevels()); // Added by NhatNX on 20110524 to get aid in J16
			if($article->access != 1 && $article->access > $aid){
				$link = JRoute::_("index.php?option=com_users&view=registration");
			}else{
				$link = JRoute::_(ContentHelperRoute::getArticleRoute($article->id, $article->catid, $article->language));
			}
		} else {
			//call from com_k2
			if (($view == "latest" || $view == "itemlist" || $view == "frontpage") && ($option=='com_content' || $option=='com_k2')) {
				if (is_file(JPATH_SITE . "/components/com_k2/helpers/route.php")) {
					include_once JPATH_SITE."/components/com_k2/helpers/route.php";
					//$link = K2HelperRoute::getItemRoute($article->id . ':' . urlencode($article->alias), $article->catid . ':' . urlencode($article->categoryalias));
					$cneedles = array (
						'item'=>(int)$article->id,
						'category'=>(int)$article->catid,
					);
					$item = K2HelperRoute::_findItem($cneedles);
					if(isset($item->id)){
						$link = K2HelperRoute::getItemRoute($article->id . ':' . urlencode($article->alias), $article->catid);
					}else{
						$link = K2HelperRoute::getItemRoute($article->id . ':' . urlencode($article->alias), $article->catid).'&Itemid='.$inputs->get('Itemid','');
					}
				}
			}
		}
		return $link;
	}

	public function removeShortcode(&$row) {
		if(isset($row->text)){
			$row->text = preg_replace($this->_plgCodeEnable, '', $row->text);
			$row->text = preg_replace($this->_plgCodeDisable, '', $row->text);
		}
		if(isset($row->introtext)){
			$row->introtext = preg_replace($this->_plgCodeEnable, '', $row->introtext);
			$row->introtext = preg_replace($this->_plgCodeDisable, '', $row->introtext);
		}
		if(isset($row->fulltext)){
			$row->fulltext = preg_replace($this->_plgCodeEnable, '', $row->fulltext);
			$row->fulltext = preg_replace($this->_plgCodeDisable, '', $row->fulltext);
		}
	}
	//Content_top_ads - Content_bottom_ads
	function displayComment(&$article, $option = 'com_content')
	{
		$app = Factory::getApplication();
		$inputs = Factory::getApplication()->input;

		$id             = $inputs->getCmd('id', 0);
		$view           = $inputs->getCmd('view');
		$show           = $inputs->getCmd('show');
		$itemid         = $inputs->get('Itemid','');
		$conntentTitle	= addslashes($article->title);

		$links = $this->getLink($article);
		$plugin = $this->plugin;
		$plgParams = $this->plgParams;

		$control_comments = $plgParams->get('control_comments',1);
		if($control_comments==1){
			if ($plgParams->get("source", "all") != 'all' && $plgParams->get("source", "all") != $option) {
				return '';
			}
		}

		require_once (JPATH_SITE.'/components/com_jacomment/helpers/jahelper.php');
		$helper = new JACommentHelpers();

		$GLOBALS['jacconfig'] = array();
		JACommentHelpers::get_config_system();
		global $jacconfig;

		if(is_null($jacconfig) || count($jacconfig) == 0) {
			if($option == 'com_k2') // k2 error with ja_social2. multip the comment box.
				return '';
			else return $this->html;
		}

		$theme = $jacconfig['layout']->get('theme', 'default');
		if (! JFolder::exists('components/com_jacomment/themes/'.$theme) && ! JFolder::exists('templates/' . $app->getTemplate() . '/html/com_jacomment/themes/' . $theme)) {
			$jacconfig['layout']->set('theme', 'default');
		}
		$theme 	= $jacconfig['layout']->get('theme', 'default' );
		$session = Factory::getSession();

		if($inputs->get("jacomment_theme", '')){
			jimport( 'joomla.filesystem.folder' );
			$themeURL = $inputs->get("jacomment_theme",'');

			if(JFolder::exists('components/com_jacomment/themes/'.$themeURL) || (JFolder::exists('templates/'.$app->getTemplate().'/html/com_jacomment/themes/'.$themeURL))){
				$theme =  $themeURL;
			}
			$session->set('jacomment_theme', $theme);
		}else{
			if($session->get('jacomment_theme', null)){
				$theme = $session->get('jacomment_theme', $theme);
			}
		}

		ob_start();
		// Put a value in a session var
		$uri = JUri::getInstance();
		$commentURL = $uri->toString();

		$session->set('commenturl', $commentURL);
		$urlRoot = JURI::root();
		$urlCom = JURI::root(true).'/components/com_jacomment';
		$urlTpl = JURI::root(true).'/templates/'.$app->getTemplate();
		$pathCom = JPATH_BASE.'/components/com_jacomment';
		$pathTpl = JPATH_BASE.'/templates/'.$app->getTemplate();

		$doc = Factory::getDocument();
		//get css and JS befor perform ajax
		if(!defined('JACOMMENT_GLOBAL_CSS')){
			//add style for japopup
			if(file_exists($pathCom.'/asset/css/ja.popup.css')){
				$doc->addStyleSheet($urlCom.'/asset/css/ja.popup.css');
			}
			//override template for japopup in template
			if(file_exists($pathTpl.'/css/ja.popup.css')){
				$doc->addStyleSheet($urlTpl.'/css/ja.popup.css');
			}

			//add style for all componennt
			if(file_exists('components/com_jacomment/asset/css/ja.comment.css')){
				$doc->addStyleSheet($urlCom.'/asset/css/ja.comment.css');
			}
			//override for all component
			if(file_exists($pathTpl.'/css/ja.comment.css')){
				$doc->addStyleSheet($urlTpl.'/css/ja.comment.css');
			}

			//add style only IE for all component
			if(file_exists('components/com_jacomment/asset/css/ja.ie.php')){
				$doc->addStyleSheet($urlCom.'/asset/css/ja.ie.php');
			}
			if(file_exists('components/com_jacomment/asset/css/css')){
				$doc->addStyleSheet($urlCom.'/asset/css/ja.ie.css');
			}
			if(file_exists($pathTpl.'/css/ja.ie.css')){
				$doc->addStyleSheet($urlTpl.'/css/ja.ie.css');
			}

			//add style of template for component
			if(file_exists('components/com_jacomment/themes/'.$theme.'/css/style.css')){
				$doc->addStyleSheet($urlCom.'/themes/'.$theme.'/css/style.css');
			}
			if(file_exists($pathTpl.'/html/com_jacomment/themes/'.$theme .'/css/style.css')){
				$doc->addStyleSheet($urlTpl.'/html/com_jacomment/themes/'.$theme.'/css/style.css');
			}

			if(file_exists($pathCom.'/themes/'.$theme.'/css/style.ie.css')){
				$doc->addStyleSheet($urlCom.'/themes/'.$theme.'/css/style_ie.css');
			}
			if(file_exists($pathTpl.'/html/com_jacomment/themes/'.$theme.'/css/style.ie.css')){
				$doc->addStyleSheet($urlTpl.'/html/com_jacomment/themes/'.$theme.'/css/style.ie.css');
			}
			//override for all component
			if(file_exists($pathTpl.'/css/ja.comment.css')){
				$doc->addStyleSheet($urlTpl.'/css/ja.comment.css');
			}

			$lang = Factory::getLanguage();
			if ( $lang->isRTL() ) {
				if(file_exists($pathCom.'/asset/css/ja.popup_rtl.css')){
					$doc->addStyleSheet($urlCom.'/asset/css/ja.popup_rtl.css');
				}
				if(file_exists($pathTpl.'/css/ja.popup_rtl.css')){
					$doc->addStyleSheet($urlTpl.'/css/ja.popup_rtl.css');
				}
				if(file_exists($pathCom.'/asset/css/ja.comment_rtl.css')){
					$doc->addStyleSheet($urlCom.'/asset/css/ja.comment_rtl.css');
				}
				if(file_exists($pathTpl.'/css/ja.comment_rtl.css')){
					$doc->addStyleSheet($urlTpl.'/css/ja.comment_rtl.css');
				}

				//add style only IE for all component
				if(file_exists($pathCom.'/asset/css/ja.ie_rtl.css')){
					$doc->addStyleSheet($urlCom.'/asset/css/ja.ie.css');
				}
				if(file_exists($pathTpl.'/css/ja.ie_rtl.css')){
					$doc->addStyleSheet($urlTpl.'/css/ja.ie_rtl.css');
				}

				if(file_exists($pathCom.'/themes/'.$theme.'/css/style_rtl.css')){
					$doc->addStyleSheet($urlCom.'/themes/'.$theme.'/css/style_rtl.css');
				}
				if(file_exists($pathTpl.'/html/com_jacomment/themes/'.$theme.'/css/style_rtl.css')){
					$doc->addStyleSheet($urlTpl.'/html/com_jacomment/themes/'.$theme.'/css/style_rtl.css');
				}

				if(file_exists($pathCom.'/themes/'.$theme.'/css/style.ie_rtl.css')){
					$doc->addStyleSheet($urlCom.'/themes/'.$theme.'/css/style_ie_rtl.css');
				}
				if(file_exists($pathTpl.'/html/com_jacomment/themes/'.$theme.'/css/style.ie_rtl.css')){
					$doc->addStyleSheet($urlTpl.'/html/com_jacomment/themes/'.$theme.'/css/style.ie_rtl.css');
				}
			}

			if(file_exists($pathTpl.'/css/ja.comment.custom.css')){
				$doc->addStyleSheet($urlTpl.'/css/ja.comment.custom.css');
			}

			define('JACOMMENT_GLOBAL_CSS', true);
		}
		if(!defined('JACOMMENT_GLOBAL_JS')){
			//JHtml::_('behavior.framework', true);

			// $doc->addScript($urlCom.'/asset/js/jquery-1.4.2.js');
			// $doc->addScript($urlCom.'/libs/bootstrap/js/jquery.js');
			if (version_compare(JVERSION, '4.0', 'ge')) {
				JHTML::_('jquery.framework');
			} else if (version_compare(JVERSION, '3.0', 'ge')) {
				$doc->addScript(JURI::root(true).'/media/jui/js/jquery.min.js');
				$doc->addScript(JURI::root(true).'/media/jui/js/jquery-noconflict.js');
				$doc->addScript(JURI::root(true).'/media/jui/js/jquery-migrate.min.js');
			} else {
				$doc->addScript($urlCom.'/libs/bootstrap/js/jquery.js');
			}
			$doc->addScript($urlCom.'/asset/js/ja.comment.js');
			$doc->addScript($urlCom.'/asset/js/ja.popup.js');

			if ($jacconfig['layout']->get('enable_character_counter', 0) == 1) {
				$doc->addScript($urlCom.'/libs/js/jquery/jquery.counter-2.2.min.js');
			}

			if ($jacconfig['layout']->get('enable_location_detection', 0) == 1) {
				$gmapKey = $jacconfig['layout']->get('custom_location_detection', 'AIzaSyDyKVaBq39PW8Sjy0nxPMKB8lJd8Qjo1Sw');
				$doc->addScript('https://maps.googleapis.com/maps/api/js?v=3&libraries=places,adsense&sensor=true&key=' . $gmapKey);
				$doc->addScript($urlCom.'/asset/js/ja.location.js');
			}

			if (version_compare(JVERSION, '4.0', 'ge')) {
				
			} else if (version_compare(JVERSION, '3.0', 'ge')) {
				if (! defined('T3V3')){
					JHtmlBootstrap::framework();
				}
			}
			else {
				$doc->addScript($urlCom.'/libs/bootstrap/js/bootstrap.min.js');
			}
			define('JACOMMENT_GLOBAL_JS', true);
		}

		if(isset($jacconfig['general']) && $jacconfig['general']->get('is_comment_offline', 0)){
			if(!JACommentHelpers::check_access($article->text)) return ;
		}

		require_once (JPATH_SITE.'/components/com_jacomment/helpers/config.php');
		JPlugin::loadLanguage( 'com_jacomment', JPATH_SITE);

		$lists['commenttype'] 	= 1;
		$lists['contentoption'] = $option;
		$lists['contentid']   	= $id;
		//Fix for component joomblog
		if($option=='com_joomblog'){
			$lists['contentid'] = $show;
		}
		$lists['jacomentUrl'] 	= $commentURL;
		$lists['contenttitle'] 	= $conntentTitle;

		$maxLength = $jacconfig['spamfilters']->get('max_length', 1000);
		?>
		<!-- BEGIN - load blog head -->
		<?php require_once $helper->jaLoadBlock("comments/head.php");	?>
		<!-- END   - load blog head -->

		<?php if(($jacconfig['layout']->get('enable_addthis')==1) || ($jacconfig['layout']->get('enable_addtoany')==1) || ($jacconfig['layout']->get('enable_tweetmeme')==1)):	?>
		<div id="jac-social-links">
			<ul>
				<?php
				if($jacconfig['layout']->get('enable_addthis')==1){
					$txtAddThis  = $jacconfig['layout']->get('custom_addthis');
					echo "<li>" .$txtAddThis. "</li>";
				}if($jacconfig['layout']->get('enable_addtoany')==1){
					echo "<li>" .$jacconfig['layout']->get('custom_addtoany'). "</li>";
				}if($jacconfig['layout']->get('enable_tweetmeme')==1){
					echo "<li>" .$jacconfig['layout']->get('custom_tweetmeme'). "</li>";
				}
				?>
			</ul>
		</div>
		<?php endif; ?>
		<div id="jac-wrapper" class="clearfix"></div>

		<script type="text/javascript">
			//<![CDATA[
			<?php if (version_compare(JVERSION, '3.0', 'ge')): ?>
			$jacJQuery = jQuery;
			$jaCmt = jQuery;
			<?php else: ?>
			$jacJQuery = $jaCmt;
			<?php endif; ?>
			$jacJQuery(document).ready(function() {
				var url = window.location.hash;
				c_url = url.split('#');
				id = 0;
				tmp = 0;
				if(c_url.length >= 1){
					for(i=1; i< c_url.length; i++){
						if(c_url[i].indexOf("jacommentid:") >-1){
							tmp = c_url[i].split(':')[1];
							if(tmp != ""){
								id = parseInt(tmp, 10);
							}
						}
					}
				}

				url = "<?php echo JRoute::_("?tmpl=component&option=com_jacomment&view=comments&contentoption=$option&contentid=".$lists['contentid']."&ran=".rand()) ?>";
				if(id != 0){
					url += "&currentCommentID=" + id;
				}
				$jacJQuery.ajax({
					method: 'get',
					url: url,
					success: function(text) {
						$jacJQuery('#jac-wrapper').html($jacJQuery('#jac-wrapper').html() + text);
						moveBackground(id, '<?php echo $urlRoot; ?>');
						jac_auto_expand_textarea();
						$jacJQuery('#jac-wrapper .conversation-avatar').tooltip();
						$jacJQuery('#jac-wrapper #jacTab a:last').on('click', function (e) {
							displayVotedComments('<?php echo $option; ?>', '<?php echo $lists['contentid']; ?>');
						});

						<?php if ($jacconfig['layout']->get('enable_character_counter', 0) == 1): ?>
						$jacJQuery('#jac-wrapper .form-character-count').popover({placement:'top', trigger:'hover'});

						$jacJQuery('#newcomment').counter({
							count: 'up',
							goal: <?php echo $maxLength; ?>,
							msg: '&nbsp;/&nbsp;<?php echo $maxLength; ?>'
						});
						$jacJQuery('#newcomment_counter').appendTo('.form-character-count');
						<?php endif ?>

						<?php if ($jacconfig['layout']->get('enable_location_detection', 0) == 1): ?>
						JALocation.initialize();
						(function() {
							// Setup drop down menu
							$jacJQuery('#jac-wrapper .dropdown-toggle').dropdown();

							// Fix input element click problem
							$jacJQuery('#jac-wrapper .dropdown input, #jac-wrapper .dropdown label, #jac-wrapper .dropdown button').click(function(e) {
								e.stopPropagation();
							});
						})($jacJQuery);
						<?php endif; ?>
					}
				});
			});
			//]]>
		</script>
		<?php
		$output = ob_get_contents();
		ob_end_clean();
		$this->html = $this->_plgStart.$output.$this->_plgEnd;
		if ($option=="com_content" && !isset($article->extra_fields)){
			$article->text .= $this->html;
		}
		else {
			return $this->html;
		}

		// return for others comment system
		$inputs->set( 'option', 'com_content' );

		//return true;
	}
}